<?php

namespace App\Interfaces;

interface ToCsvInterface
{
    public function generateSalaries();
}
