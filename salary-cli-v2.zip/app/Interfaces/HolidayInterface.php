<?php

namespace App\Interfaces;

interface HolidayInterface
{
    function addHolidays(array $holidays);
    function getHolidays();
}
